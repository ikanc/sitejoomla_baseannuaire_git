

Hello there!

Thank you for choosing Tabs + Accordion.
Documentation and support is available at http://lamovo.com/support/tabs+accordion